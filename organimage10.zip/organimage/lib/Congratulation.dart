import 'package:flutter/material.dart';

import 'main.dart';

class Congratulation extends StatelessWidget {
  const Congratulation({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('congratulation'),
        ),
        body: Column(children: <Widget>[
          AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(
                  Radius.circular(40),
                ),
              ),
              title: Text(
                'congratulation afer $moves  moves',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 26.0),
              )),
          Center(
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                moves = 0;
              },
              child: const Text('Go back!'),
            ),
          ),
        ]));
  }
}
