import 'package:flutter/material.dart';

import 'PlayPage.dart';

class MyHomePage extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(),
        drawer: Drawer(),
        body: SingleChildScrollView(
            child: Column(children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 1,
                child: Center(child: Text("organimage for hackathone")),
              )
            ],
          ),
          //  Flexible(
          //   child:

          Divider(
            color: Colors.grey.shade600,
          ),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 5,
                child: Container(
                  width: double.infinity,
                  height: 300,
                  decoration: BoxDecoration(
                    // color: const Color(0xff7c94b6),
                    image: const DecorationImage(
                      //  image: AssetImage('assets/crossflutter.jpg'),
                      image: AssetImage('assets/b1.gif'),
                      fit: BoxFit.fill,
                    ), //   height: 150,
                  ),
                ),
              ),
            ],
          ),
          //   ),

          Divider(
            color: Colors.grey.shade600,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 1,
                // child: Center(
                child: ElevatedButton(
                    child: Text("Play"),
                    onPressed: () {
                      navigateToPlayPage(context);
                    }),
              ) //)
            ],
          ),
          Divider(
            color: Colors.grey.shade600,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                flex: 1,
                // child: Center(
                child: ElevatedButton(
                    child: Text("close"),
                    onPressed: () {
                      Navigator.pop(context);
                    }),
              ) //)
            ],
          ),
        ])));
  }

  void navigateToPlayPage(BuildContext context) {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => PlayPage()));
  }
}
